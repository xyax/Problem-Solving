#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import collections
import math
import operator

