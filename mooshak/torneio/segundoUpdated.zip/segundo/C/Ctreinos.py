#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import operator
import math
import collections

